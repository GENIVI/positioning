#! /usr/bin/env python3 

# Convert a GENIVI positioning log form format 1.0 to format 2.0
# Initially, only the sentences GVGPSC, GVGPSP, GVVEHSP are converted
# This is enough for the geneve-cologny.gvsl log which is the reference log for the navit-poc

###########################################################################
# @licence app begin@
# SPDX-License-Identifier: MPL-2.0
#
# Component Name: LogReplayer
# Author: Helmut Schmidt <Helmut.3.Schmidt@continental-corporation.com>
#
# Copyright (C) 2014, Continental Automotive GmbH
# 
# License:
# This Source Code Form is subject to the terms of the
# Mozilla Public License, v. 2.0. If a copy of the MPL was not distributed with
# this file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# # @licence end@
###########################################################################


#####################################
# Imports
#####################################

import sys
import re
import argparse
import math


###########################################################
# Configuration Parameters, can also be set by command line
###########################################################

#debug flag
c_debug = False


##################################################################
# Function definitions to write GENIVI Positioning Log - GNSS part
##################################################################

#write GVGNSP - GNSS (simple) Position
def writeGVGNSP (file, v1fields):
    #example v1 fields: 5157$GVGPSP,3,46.202026,6.146818,0
    valid = 0
    v1timestamp = int(v1fields[0])
    v1valid = int(v1fields[2])
    v1lat = v1fields[3]
    v1lon = v1fields[4]
    v1alt = v1fields[5]
    file.write("{0:09d},0$GVGNSP,{0:09d},".format(v1timestamp))
    if (v1valid & 0x01):
        valid |= 0x01
        file.write("{0},".format(v1lat))
    else:
        file.write("0,")
    if (v1valid & 0x02):
        valid |= 0x02
        file.write("{0},".format(v1lon))
    else:
        file.write("0,")
    if (v1valid & 0x04):
        valid |= 0x04
        file.write("{0},".format(v1alt))
    else:
        file.write("0,")
    file.write("0X{0:02X}".format(valid))
    file.write("\n")
    return

#write GVGNSC - GNSS (simple) Course
def writeGVGNSC (file, v1fields):
    #example v1 fields: 5157$GVGPSC,3,11.111111,44.000000,11
    valid = 0
    v1timestamp = int(v1fields[0])
    v1valid = int(v1fields[2])
    v1speed = v1fields[3]
    v1heading = v1fields[4]
    v1climb = v1fields[5]
    file.write("{0:09d},0$GVGNSC,{0:09d},".format(v1timestamp))
    if (v1valid & 0x01):
        valid |= 0x01
        file.write("{0},".format(v1speed))
    else:
        file.write("0,")
    if (v1valid & 0x04):
        valid |= 0x02
        file.write("{0},".format(v1climb))
    else:
        file.write("0,")
    if (v1valid & 0x02):
        valid |= 0x04
        file.write("{0},".format(v1heading))
    else:
        file.write("0,")
    file.write("0X{0:02X}".format(valid))
    file.write("\n")
   

##################################################################
# Function definitions to write GENIVI Positioning Log - SNS part
##################################################################

#write GVSNSVEHSP: Vehicle Speed
def writeGVSNSVEHSP (file, v1fields):
    #example v1 fields: 4147$GVVEHSP,1,23.43
    valid = 0
    v1timestamp = int(v1fields[0])
    v1valid = int(v1fields[2])
    v1speed = v1fields[3]
    file.write("{0:09d},0$GVSNSVEHSP,{0:09d},".format(v1timestamp))
    if (v1valid & 0x01):
        valid |= 0x01
        file.write("{0},".format(v1speed))
    else:
        file.write("0,")
    file.write("0X{0:02X}".format(valid))
    file.write("\n")

  
#####################################
# Main program
#####################################
  
  

# 
# Process command line arguments
#

parser = argparse.ArgumentParser()
parser.add_argument("logv1", help="name of the log format 1 file which is read as input")
parser.add_argument("logv2", help="name of the log format 1 file which is written as output")
parser.add_argument("--debug", action='count', help="print additional debug info to output file")
args = parser.parse_args()
  
if len(sys.argv)>2:
    infile = args.logv1
    outfile = args.logv2
    c_debug = args.debug
else:
    parser.print_help()
    sys.exit("")
    
#print (infile)
#print (outfile)

try:
    fi = open (infile, "r") #"r" is default, so it cout be left away
except:
    sys.exit("Error: Cannot open "+infile+" for reading")

try:
    fo = open (outfile, "w")
except:
    sys.exit("Error: Cannot open "+outfile+" for writing")

fo.write("#Log file generated from the gvl1to2.py converter\n")
fo.write("#Original log file: "+infile+"\n")
fo.write("0,0$GVGNSVER,2,0,0\n")
fo.write("0,0$GVSNSVER,2,0,0\n")


#
# iterate over input file
#



for line in fi:
    line = line.rstrip() #remove \r\n at end of string
    #split by "," and "$", so a simple 'line.split(",")' wont't work
    #fields = line.split(",")
    fields = re.split('[,$]', line)
    if (len(fields) >= 4 ) and (fields[1] == "GVVEHSP"):
        #example: 4147$GVVEHSP,1,23.43
        fo.write("#"+line+"\n")
        writeGVSNSVEHSP (fo, fields)
    elif (len(fields) >= 6 ) and (fields[1] == "GVGPSP"):
        #example: 5157$GVGPSP,3,46.202026,6.146818,0
        fo.write("#"+line+"\n")
        writeGVGNSP (fo, fields)
    elif (len(fields) >= 6 ) and (fields[1] == "GVGPSC"):
        #example: 5157$GVGPSC,3,11.111111,44.000000,11
        fo.write("#"+line+"\n")
        writeGVGNSC (fo, fields)
    else:
        print("Unknown sentence type {0}\n".format(fields[1]))


#end of the loop

#
# clean up: close files
#

fi.close()
fo.close()